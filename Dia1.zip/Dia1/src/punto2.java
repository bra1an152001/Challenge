
public class punto2 {

	public static void main(String[] args) {

	}

}
